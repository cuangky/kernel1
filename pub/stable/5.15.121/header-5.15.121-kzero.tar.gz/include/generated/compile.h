/* This file is auto generated, version 1 */
/* SMP PREEMPT */
#define UTS_MACHINE "aarch64"
#define UTS_VERSION "#1 SMP PREEMPT Mon Nov 20 12:05:47 EST 2023"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "fv-az1535-47"
#define LINUX_COMPILER "aarch64-none-linux-gnu-gcc (Arm GNU Toolchain 13.2.rel1 (Build arm-13.7)) 13.2.1 20231009, GNU ld (Arm GNU Toolchain 13.2.rel1 (Build arm-13.7)) 2.41.0.20231009"
