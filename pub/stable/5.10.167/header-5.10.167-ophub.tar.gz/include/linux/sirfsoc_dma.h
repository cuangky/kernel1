/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _SIRFSOC_DMA_H_
#define _SIRFSOC_DMA_H_

bool sirfsoc_dma_filter_id(struct dma_chan *chan, void *chan_id);

#endif
