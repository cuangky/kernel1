/* This file is auto generated, version 1 */
/* SMP PREEMPT */
#define UTS_MACHINE "aarch64"
#define UTS_VERSION "#1 SMP PREEMPT Tue Nov 21 02:59:42 EST 2023"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "fv-az735-668"
#define LINUX_COMPILER "aarch64-none-linux-gnu-gcc (Arm GNU Toolchain 13.2.rel1 (Build arm-13.7)) 13.2.1 20231009, GNU ld (Arm GNU Toolchain 13.2.rel1 (Build arm-13.7)) 2.41.0.20231009"
